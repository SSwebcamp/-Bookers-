class BooksController < ApplicationController
  
  #投稿フォームを作成する
  def index 
    @books = Book.all
    @book = Book.new
  end

  #Showクリック→URL(books/n)へ遷移
  def show
    @book = Book.find(params[:id])
  end
  
  #新規投稿→投稿内容を表示、URL(books/n)へ遷移
  def create
    @book = Book.new(book_params)
    if @book.save
      # 成功したとき
      redirect_to book_path(@book.id)
    else
      # 失敗したとき
      @books = Book.all
      render :index
    end
  end
  
  #Editクリック→URL(books/n/edit)へ遷移
  def edit
    @book = Book.find(params[:id])
  end
  
  #backクリック→新規投稿ページへ遷移、URL(books)
  def back
    book = Book.new(book_params)
    book.save
    redirect_to book_path(book.id)
  end
  
  def update
    #インスタンス変数に代入する(ControllerからViewへ変数を渡す)
    @book = Book.find(params[:id])
    if @book.update(book_params)
      #成功したとき　
      redirect_to book_path(@book.id)
    else
      #失敗したとき
      @books = Book.all
      render :edit
    end
  end
  
  def destroy
    book = Book.find(params[:id])
    book.destroy
    redirect_to books_path
  end
  
  private
  def book_params
    params.require(:book).permit(:title, :body)
  end

end


# 1,topページ→2,booksページ(投稿)→3,books/???→4,books/???/edit or 2へ
# comのhtmlはtop.html.erb
# com/booksのhtmlはindex.html.erb
# com/books/???/editのhtmlはedit.html.erb

#1はdef create
#2はdef index
#3はdef show
#4はdef edit

#Bookというモデル/クラスがある場合、これに対応するデータベースのテーブルはbooksになる
#マイグレーション=データ移行